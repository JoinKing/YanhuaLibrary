package com.example.goujin_sever.facedome.capture;

import android.graphics.Bitmap;

/**
 * Created by dong on 2018/5/23.
 */

public interface CameraListener {

    void onCaptured(Bitmap bitmap);

}
